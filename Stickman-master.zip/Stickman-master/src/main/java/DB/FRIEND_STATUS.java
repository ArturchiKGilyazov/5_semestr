package DB;

public enum FRIEND_STATUS {
    FRIENDSHIP,

}
