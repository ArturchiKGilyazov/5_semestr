package exceptions;

public class NoAvailableIDException extends Exception {
}
