package exceptions;

public class NoResponse extends Exception{
}
