package exceptions;

import java.util.NoSuchElementException;

public class NoSuchGameException extends NoSuchElementException {
}
