package exceptions;

import java.util.NoSuchElementException;

public class NoSuchPlayerException extends NoSuchElementException {
}
