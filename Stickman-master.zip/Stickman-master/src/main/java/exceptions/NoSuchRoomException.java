package exceptions;

public class NoSuchRoomException extends Exception {
}
