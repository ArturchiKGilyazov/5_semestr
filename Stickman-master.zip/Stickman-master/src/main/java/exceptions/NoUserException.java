package exceptions;

public class NoUserException extends Throwable {
}
