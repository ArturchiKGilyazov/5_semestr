package exceptions;

public class UnknownTypeOfRequest extends Exception{
}
