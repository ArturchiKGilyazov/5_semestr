package exceptions;

public class UserAreNotAdmin extends Exception {
}
