package friend;

public enum FRIEND_STATUS {
    FRIENDSHIP,
    INCOMING,
    OUTGOING
}
