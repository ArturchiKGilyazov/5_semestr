package game;

public abstract class Player_A implements Player_I {
    static final float HeadRadius = 0;
    static final float HandWeight = 0;
    static final float FootWeight = 0;
    static final float TorsoWeight = 0;
    static final float HandHeight = 0;
    static final float FootHeight = 0;
    static final float TorsoHeight = 0;
}
