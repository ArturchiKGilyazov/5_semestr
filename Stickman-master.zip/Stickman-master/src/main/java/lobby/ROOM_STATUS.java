package lobby;

public enum ROOM_STATUS {
    FOR_DELETE
}
