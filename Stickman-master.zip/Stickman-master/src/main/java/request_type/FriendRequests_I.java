package request_type;

import com.google.protobuf.MessageLite;
import proto_files.DangerStickman;
import proto_files.FriendMessages;

public interface FriendRequests_I extends Requests_I{

}