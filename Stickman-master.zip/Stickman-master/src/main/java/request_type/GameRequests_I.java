package request_type;

import com.google.protobuf.MessageLite;
import proto_files.DangerStickman;

public interface GameRequests_I extends Requests_I{

}
