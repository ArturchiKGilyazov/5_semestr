package request_type;

public interface LobbyRequests_I extends Requests_I{

}
