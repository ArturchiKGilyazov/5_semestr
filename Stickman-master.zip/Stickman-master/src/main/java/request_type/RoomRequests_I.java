package request_type;

public interface RoomRequests_I extends Requests_I {

}