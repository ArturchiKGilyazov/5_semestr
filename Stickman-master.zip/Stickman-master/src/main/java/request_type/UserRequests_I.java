package request_type;

import com.google.protobuf.MessageLite;

public interface UserRequests_I extends Requests_I{
}
