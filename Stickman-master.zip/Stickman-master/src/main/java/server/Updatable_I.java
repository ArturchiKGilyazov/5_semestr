package server;

public interface Updatable_I {
    void update();
}
