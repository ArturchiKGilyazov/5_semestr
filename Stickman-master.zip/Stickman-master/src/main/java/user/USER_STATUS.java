package user;

public enum USER_STATUS {
    ONLINE,
    DISCONNECTED,
    CHANGED
}
